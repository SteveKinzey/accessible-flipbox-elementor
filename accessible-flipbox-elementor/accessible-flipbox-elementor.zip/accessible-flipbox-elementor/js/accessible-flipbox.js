(function($){
    $(document).ready(function(){
        $('.elementor-flip-box__front').attr('role','button').attr('tabindex','0').each(function(index){
            var frontId = 'flipbox-' + (index+1) + '-front';
            var backId = 'flipbox-' + (index+1) + '-back';
            $(this).attr('id', frontId).attr('aria-controls', backId).attr('aria-expanded', 'false');
            $(this).on('keydown', function(e){
                if(e.key === 'Enter' || e.key === ' '){
                    e.preventDefault();
                    $('#' + backId).attr('aria-hidden', function(_, attr){ return attr === 'true' ? 'false' : 'true'; });
                    $(this).attr('aria-expanded', function(_, attr){ return attr === 'false' ? 'true' : 'false'; });
                }
            });
        });
        $('.elementor-flip-box__back').attr('aria-hidden', 'true');
    });
})(jQuery);
