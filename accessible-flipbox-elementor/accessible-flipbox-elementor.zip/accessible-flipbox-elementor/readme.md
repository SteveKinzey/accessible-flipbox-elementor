# Accessible Flipbox for Elementor

## Description
This WordPress plugin enhances Elementor Flipbox widgets for accessibility by adding ARIA attributes, keyboard navigation, and improved structure.

## Installation
1. Download the ZIP file.
2. Go to WordPress Admin → Plugins → Add New → Upload Plugin.
3. Upload the ZIP and activate.

## Usage
- Automatically detects Flipboxes and adds ARIA roles.
- Use **Tab** and **Enter/Space** to flip.

## How it Works
- If the flipbox contains a button, keyboard focus moves to the button.
- Without a button, the front panel is clickable and toggles the back.

## Support
- Email: pluginsupport@sk-america.com
