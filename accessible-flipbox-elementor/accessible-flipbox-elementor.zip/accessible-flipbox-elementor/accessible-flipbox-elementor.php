<?php
/*
Plugin Name: Accessible Flipbox for Elementor
Plugin URI: https://github.com/SteveKinzey/accessible-flipbox-elementor
Description: Enhances Elementor Flipbox accessibility by adding ARIA attributes and keyboard navigation.
Version: 1.0.0
Author: Stephen Kinzey, PhD
Author URI: https://sk-america.com
Contributors: SK America
Email: steve@sk-america.com
Support: pluginsupport@sk-america.com
License: GPL2
*/

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Enqueue custom JavaScript
function afe_enqueue_scripts() {
    wp_enqueue_script( 'accessible-flipbox', plugin_dir_url( __FILE__ ) . 'js/accessible-flipbox.js', array('jquery'), '1.0.0', true );
}
add_action( 'wp_enqueue_scripts', 'afe_enqueue_scripts' );
?>
